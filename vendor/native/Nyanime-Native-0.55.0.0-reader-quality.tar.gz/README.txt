Nyanime reader image engine - corresponding native sources

This package contains the complete pinned NCNN source archive, original JNI
adapter, CMake/build/verifier recipes, toolchain identification, four-ABI source
and binary hashes, and license notices. Models are not included in the APK or
this package; see core/reader-quality/NOTICE.md for their provenance and terms.

Requirements: Linux x86_64, Python3.11+, CMake3.22+, Ninja, Android NDK r28c
28.2.13676358. Build on a Linux filesystem, not /mnt/c under WSL.

Offline source setup and rebuild from the extracted package root:
  mkdir -p /tmp/nyanime-reader-quality
  cp sources/ncnn-20240410.tar.gz /tmp/nyanime-reader-quality/
  python3 scripts/build_reader_quality_native.py --ndk /path/to/android-ndk-r28c     --work-dir /tmp/nyanime-reader-quality --abi all --jobs 2
  python3 scripts/verify_reader_quality_native.py

Build outputs: .local/reader-quality-native/jniLibs/<ABI>/.
NCNN is CPU only (no Vulkan/OpenMP/tools/examples/tests); API26, static C++
runtime, 16KiB ELF load alignment, prefix-mapped source/build locations.
No shader/model inference input, source credentials or personal data are present.
The separate complete Nyanime source archive contains the Android/Kotlin host.
